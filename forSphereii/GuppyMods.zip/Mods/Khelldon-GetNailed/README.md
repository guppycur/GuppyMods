# Get Nailed! Nail recipe mod
This modlet adds nails to most wooden blocks and items that should have nails in their recipes. 
It adds bent nails into the world. 
When destroying blocks use a hammer to get straight nails or you get bent nails
Repairing blocks requires nails.
More nails and bent nails added to loot spawns