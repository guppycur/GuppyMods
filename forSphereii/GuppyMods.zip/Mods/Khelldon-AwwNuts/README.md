# Awwww Nuts!
This modlet adds nuts and bolts into the game. Nuts and Bolts are used to attached metal items and blocks together.
