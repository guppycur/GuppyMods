Guppycur's Blood Moon Trickle Fix
=================================

This mod adds in more zombies in the final stages of the blood moon horde, increasing the zombies until morning.