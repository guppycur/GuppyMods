# Complex Cobble!
This modlet changes the recipes for cobblestone to make it more difficult to craft.
