The Zombie Transmogrifier
-------------------------

The Zombie Transmogrifier shakes things up in the apocalypse by adding a random twists to the spawned in zombies. Hal9000's Run in Dark mod has been expanded to include more random elements in the world.

1) Random Walk Types - No more adding the same zombies in the entityclasses; This mod randomizes all spawned in zombies to various Walk Types
2) Random Approach Speeds - Everyone walks, shuffles and runs at different speeds. Did the apocalypse change that? Hell no! 
3) Random Heights - Was the apocalypse based in Kamino? Hell no! Random sizes for all the zombies
4) Random Run in Dark - There's a small chance the next zombie you meet in the burnt out house can run... Will you be ready for them?

