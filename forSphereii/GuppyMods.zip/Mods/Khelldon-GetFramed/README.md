# Frames with no glue
This changes wood frames so they don't have glue and need to be stacked and nailed together when building.
